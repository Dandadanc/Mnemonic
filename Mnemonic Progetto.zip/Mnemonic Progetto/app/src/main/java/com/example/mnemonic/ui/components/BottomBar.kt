package com.example.mnemonic.ui.components


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp


@Composable
fun BottomBar(
    onMemoriesClick: () -> Unit,
    onSettingsClick: () -> Unit
) {


    val gradient = Brush.horizontalGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.95f),
            Color(0xFFEDE7F6)
        )
    )


    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .height(70.dp)
            .background(
                brush = gradient,
                shape = RoundedCornerShape(25.dp)
            ),
        contentAlignment = Alignment.Center
    ) {


        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {


            TextButton(onClick = onMemoriesClick) {
                Text("Ricordi")
            }


            TextButton(onClick = onSettingsClick) {
                Text("Impostazioni")
            }
        }
    }
}