package com.example.mnemonic.data


import com.google.firebase.auth.FirebaseAuth


object FirebaseAuthManager {


    private val auth = FirebaseAuth.getInstance()


    fun login(email: String, password: String, callback: (Boolean, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { callback(true, null) }
            .addOnFailureListener { callback(false, it.message) }
    }


    fun register(email: String, password: String, callback: (Boolean, String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { callback(true, null) }
            .addOnFailureListener { callback(false, it.message) }
    }


    fun logout() {
        auth.signOut()
    }


    fun isLogged(): Boolean {
        return auth.currentUser != null
    }
}