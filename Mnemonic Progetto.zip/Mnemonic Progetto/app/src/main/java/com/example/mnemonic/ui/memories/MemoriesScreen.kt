package com.example.mnemonic.ui.memories


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mnemonic.data.model.Memory

@Composable
fun MemoriesScreen(
    memories: List<Memory>,
    onBack: () -> Unit
) {


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {


        Text("🧠 Ricordi salvati", style = MaterialTheme.typography.headlineMedium)


        Spacer(modifier = Modifier.height(20.dp))


        memories.forEach { memory ->


            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(memory.title, style = MaterialTheme.typography.titleMedium)
                    Text(memory.description)
                }
            }
        }


        Spacer(modifier = Modifier.height(20.dp))


        Button(onClick = onBack) {
            Text("Indietro")
        }
    }
}