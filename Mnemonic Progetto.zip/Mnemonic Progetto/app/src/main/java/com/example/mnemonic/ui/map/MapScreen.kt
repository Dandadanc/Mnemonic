package com.example.mnemonic.ui.map


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun MapScreen(
    onLogout: () -> Unit
) {


    var tab by remember { mutableStateOf("map") }


    Column(modifier = Modifier.fillMaxSize()) {


        Box(modifier = Modifier.weight(1f)) {


            when (tab) {


                "map" -> Text("MAPPA (Google Maps qui)")


                "memories" -> Text("RICORDI SALVATI")


                "settings" -> Column {


                    Text("SETTINGS")


                    Spacer(Modifier.height(10.dp))


                    Button(onClick = onLogout) {
                        Text("Logout")
                    }


                    Spacer(Modifier.height(20.dp))


                    Text("by Cito Daniele & Giorgia Re")
                }
            }
        }


        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {


            Button(onClick = { tab = "map" }) {
                Text("Mappa")
            }


            Button(onClick = { tab = "memories" }) {
                Text("Ricordi")
            }


            Button(onClick = { tab = "settings" }) {
                Text("Settings")
            }
        }
    }
}