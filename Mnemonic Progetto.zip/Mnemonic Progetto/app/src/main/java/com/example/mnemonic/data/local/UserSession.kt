package com.example.mnemonic.data.local

import android.content.Context


class UserSession(context: Context) {


    private val prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)


    fun saveUser(email: String, password: String) {
        prefs.edit()
            .putString("email", email)
            .putString("password", password)
            .apply()
    }


    fun getEmail(): String? = prefs.getString("email", null)


    fun getPassword(): String? = prefs.getString("password", null)


    fun isUserRegistered(): Boolean {
        return !getEmail().isNullOrEmpty()
    }


    fun clear() {
        prefs.edit().clear().apply()
    }
}