data class Memory(
    val title: String,
    val description: String,
    val latitude: Double? = null,
    val longitude: Double? = null
)