class LoginActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContent {


            MnemonicTheme {


                LoginScreen(
                    onLoginSuccess = {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                        )
                        finish()
                    }
                )
            }
        }
    }
}