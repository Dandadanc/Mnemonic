@Composable
fun SettingsScreen(
    onLogout: () -> Unit
) {


    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {


        Button(onClick = onLogout) {
            Text("Logout")
        }


        Spacer(Modifier.height(20.dp))


        Text("by Cito Daniele & Giorgia Re")
    }
}