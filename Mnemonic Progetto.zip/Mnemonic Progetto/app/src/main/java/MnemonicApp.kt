package com.example.mnemonic


import android.app.Application
import com.google.firebase.FirebaseApp


class MnemonicApp : Application() {


    override fun onCreate() {
        super.onCreate()


        // 🔥 Inizializza Firebase
        FirebaseApp.initializeApp(this)
    }
}