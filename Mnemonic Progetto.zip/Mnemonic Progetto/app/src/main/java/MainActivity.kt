package com.example.mnemonic


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.mnemonic.ui.login.LoginScreen
import com.example.mnemonic.ui.map.MapScreen
import com.google.firebase.auth.FirebaseAuth


class MainActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContent {


            var logged by remember {
                mutableStateOf(FirebaseAuth.getInstance().currentUser != null)
            }


            if (!logged) {


                LoginScreen(
                    onLoginSuccess = {
                        logged = true
                    }
                )


            } else {


                MapScreen(
                    onLogout = {
                        FirebaseAuth.getInstance().signOut()
                        logged = false
                    }
                )
            }
        }
    }
}