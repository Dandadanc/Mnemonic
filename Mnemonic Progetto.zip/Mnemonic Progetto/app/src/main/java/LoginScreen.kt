package com.example.mnemonic.ui.login


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.mnemonic.data.FirebaseAuthManager


@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {


    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {


        Text("Mnemonic", style = MaterialTheme.typography.headlineLarge)


        Spacer(Modifier.height(20.dp))


        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                error = ""
            },
            label = { Text("Email") }
        )


        Spacer(Modifier.height(10.dp))


        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                error = ""
            },
            label = { Text("Password") }
        )


        if (error.isNotEmpty()) {
            Text(error, color = Color.Red)
        }


        Spacer(Modifier.height(10.dp))


        Button(onClick = {


            if (!email.contains("@")) {
                error = "Email non valida"
                return@Button
            }


            if (password.length < 6) {
                error = "Password minimo 6 caratteri"
                return@Button
            }


            FirebaseAuthManager.login(email, password) { success, msg ->
                if (success) onLoginSuccess()
                else error = msg ?: "Errore login"
            }


        }) {
            Text("Login")
        }


        Spacer(Modifier.height(10.dp))


        Button(onClick = {


            FirebaseAuthManager.register(email, password) { success, msg ->
                if (success) onLoginSuccess()
                else error = msg ?: "Errore registrazione"
            }


        }) {
            Text("Registrati")
        }
    }
}